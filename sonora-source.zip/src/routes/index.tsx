import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronLeft, Mail, Smartphone, Home, Search, Library, Plus, Pause, Play, MonitorSpeaker, MoreHorizontal, PlusCircle, Zap, Clock, Megaphone, Settings, SquarePen, X, Eye, EyeOff, Share } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sonora — Music streaming" },
      { name: "description", content: "Listen to music, mixes and podcasts." },
      { property: "og:title", content: "Sonora — Music streaming" },
      { property: "og:description", content: "Listen to music, mixes and podcasts." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
    links: [{ rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" }],
  }),
  component: App,
});

type Screen = "signup" | "loginOptions" | "loginForm" | "home" | "search" | "profile" | "library";

const songs = [
  ["Terapia", "Mc Kevin", 200], ["777-666", "Matuê", 320], ["1993", "Matuê", 220], ["Sempre Tem", "Mc IG, DJ Glenner", 90],
  ["Geme Baixo", "MC Jvila, Menor MC", 340], ["MDT", "Mc Kelvinho, MC Jvila", 30], ["Flashing Lights", "Kanye West, Dwele", 290], ["Sad Girl", "Lana Del Rey", 0],
] as const;

function Cover({ hue, size = "size-14" }: { hue: number; size?: string }) {
  return <div className={`${size} shrink-0 rounded`} style={{ background: `linear-gradient(135deg, oklch(0.6 0.15 ${hue}), oklch(0.25 0.08 ${hue + 60}))` }} />;
}

function Logo({ className = "size-16" }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className}><circle cx="32" cy="32" r="32" fill="currentColor" />
      <g stroke="var(--background)" strokeWidth="5.5" strokeLinecap="round" fill="none">
        <path d="M15 25c12-4.5 24-3.5 34 2.5" /><path d="M17.5 33.5c10-3.5 20-2.5 29 2.5" /><path d="M20 41.5c7.5-2.5 15.5-2 23 2" /></g></svg>
  );
}

function AuthButton({ icon, label, primary, onClick }: { icon: React.ReactNode; label: string; primary?: boolean; onClick?: () => void }) {
  return (
    <button onClick={onClick} className={`relative flex h-12 w-full items-center justify-center rounded-full font-bold ${primary ? "bg-primary text-primary-foreground" : "border border-border"}`}>
      <span className="absolute left-5">{icon}</span>{label}
    </button>
  );
}

function App() {
  const [screen, setScreen] = useState<Screen>("signup");
  const [drawer, setDrawer] = useState(false);
  const [playing, setPlaying] = useState(true);
  const [track, setTrack] = useState<readonly [string, string, number]>(songs[0]);
  const [recent, setRecent] = useState<(typeof songs)[number][]>([...songs]);
  const [showPw, setShowPw] = useState(false);
  const [user, setUser] = useState(""); const [pw, setPw] = useState("");
  const authed = !["signup", "loginOptions", "loginForm"].includes(screen);

  const G = <span className="text-lg font-extrabold" style={{ color: "oklch(0.65 0.18 250)" }}>G</span>;

  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col bg-background">
      {screen === "signup" && (
        <div className="flex min-h-screen flex-col justify-end px-8 pb-12">
          <div className="flex flex-col items-center gap-6">
            <Logo />
            <h1 className="text-center text-3xl font-extrabold">Sign up to start listening</h1>
            <div className="flex w-full flex-col gap-3">
              <AuthButton primary icon={<Mail />} label="Continue with email" onClick={() => setScreen("home")} />
              <AuthButton icon={<Smartphone />} label="Continue with phone number" />
              <AuthButton icon={G} label="Continue with Google" />
              <AuthButton icon={<span className="text-xl"></span>} label="Continue with Apple" />
            </div>
            <p className="mt-4">Already have an account?</p>
            <button className="text-lg font-bold" onClick={() => setScreen("loginOptions")}>Log in</button>
          </div>
        </div>
      )}
      {screen === "loginOptions" && (
        <div className="flex min-h-screen flex-col px-8 pb-12">
          <button className="mt-4 -ml-3" onClick={() => setScreen("signup")}><ChevronLeft className="size-8" /></button>
          <div className="mt-auto flex flex-col items-center gap-6">
            <Logo /><h1 className="text-3xl font-extrabold">Log in to Sonora</h1>
            <div className="flex w-full flex-col gap-3">
              <AuthButton primary icon={<Mail />} label="Continue with email" onClick={() => setScreen("loginForm")} />
              <AuthButton icon={<Smartphone />} label="Continue with phone number" />
              <AuthButton icon={G} label="Continue with Google" />
              <AuthButton icon={<span className="font-extrabold text-link">f</span>} label="Continue with Facebook" />
              <AuthButton icon={<span className="text-xl"></span>} label="Continue with Apple" />
            </div>
            <p className="mt-4">Don't have an account?</p>
            <button className="text-lg font-bold" onClick={() => setScreen("signup")}>Sign up</button>
          </div>
        </div>
      )}
      {screen === "loginForm" && (
        <div className="px-5 pt-4">
          <div className="relative flex items-center justify-center py-2">
            <button className="absolute left-0" onClick={() => setScreen("loginOptions")}><ChevronLeft className="size-7" /></button>
            <span className="font-bold">Log in</span>
          </div>
          <label className="mt-8 block text-2xl font-extrabold">Email or username</label>
          <input value={user} onChange={(e) => setUser(e.target.value)} className="mt-2 h-14 w-full rounded border bg-surface px-4 outline-none" />
          <label className="mt-6 block text-2xl font-extrabold">Password</label>
          <div className="relative mt-2">
            <input type={showPw ? "text" : "password"} value={pw} onChange={(e) => setPw(e.target.value)} className="h-14 w-full rounded border bg-surface px-4 pr-12 outline-none" />
            <button className="absolute right-4 top-4" onClick={() => setShowPw(!showPw)}>{showPw ? <Eye /> : <EyeOff />}</button>
          </div>
          <div className="mt-10 flex flex-col items-center gap-4">
            <button disabled={!user || !pw} onClick={() => setScreen("home")} className="h-14 rounded-full bg-foreground px-10 font-bold text-primary-foreground disabled:bg-surface-2">Log in</button>
            <button className="rounded-full border px-8 py-2 text-sm font-bold">Log in without password</button>
          </div>
        </div>
      )}

      {authed && (
        <>
          <main className="flex-1 overflow-y-auto pb-40">
            {screen === "home" && (
              <div className="px-4 pt-4">
                <div className="flex items-center gap-2 overflow-x-auto">
                  <button onClick={() => setDrawer(true)} className="grid size-9 shrink-0 place-items-center rounded-full bg-avatar font-bold text-primary-foreground">J</button>
                  {["All", "Music", "Podcasts", "Audiobooks"].map((c, i) => (
                    <span key={c} className={`shrink-0 rounded-full px-4 py-1.5 text-sm ${i === 0 ? "bg-primary text-primary-foreground" : "bg-surface-2"}`}>{c}</span>
                  ))}
                </div>
                <p className="mt-6 text-xs text-muted-foreground">Jump into a session based on your tastes</p>
                <h2 className="text-2xl font-extrabold">Start listening</h2>
                {songs.slice(0, 3).map((s) => (
                  <button key={s[0]} onClick={() => { setTrack(s); setPlaying(true); }} className="mt-3 flex w-full items-center gap-3 text-left">
                    <Cover hue={s[2]} /><div className="flex-1"><div>{s[0]}</div><div className="text-sm text-muted-foreground">{s[1]}</div></div><MoreHorizontal className="text-muted-foreground" />
                  </button>
                ))}
                <h2 className="mt-8 text-2xl font-extrabold">To get you started</h2>
                <div className="mt-3 flex gap-4 overflow-x-auto">
                  {[["Yebba Mix", "Frank Ocean, Sonder and Drake", 140], ["21 Savage Mix", "Gunna, J. Cole and Quavo", 270], ["Luan Mix", "Cristiano, Victor Hugo", 100]].map(([t, d, h]) => (
                    <div key={t as string} className="w-36 shrink-0">
                      <Cover hue={h as number} size="size-36" />
                      <p className="mt-2 text-sm font-bold">{t}</p><p className="text-xs text-muted-foreground">{d}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {screen === "search" && (
              <div>
                <div className="flex items-center gap-3 bg-surface px-4 py-3">
                  <input placeholder="What do you want to listen to?" className="h-10 flex-1 rounded-lg border bg-transparent px-3 outline-none placeholder:text-muted-foreground" />
                  <button onClick={() => setScreen("home")}>Cancel</button>
                </div>
                <div className="px-4">
                  <h2 className="mt-4 text-xl font-extrabold">Recent searches</h2>
                  {recent.map((s) => (
                    <div key={s[0]} className="mt-4 flex items-center gap-3">
                      <button className="flex flex-1 items-center gap-3 text-left" onClick={() => { setTrack(s); setPlaying(true); }}>
                        <Cover hue={s[2]} /><div className="min-w-0"><div className={track[0] === s[0] ? "text-primary" : ""}>{s[0]}</div><div className="truncate text-sm text-muted-foreground">Song • {s[1]}</div></div>
                      </button>
                      <PlusCircle className="text-muted-foreground" /><button onClick={() => setRecent(recent.filter((r) => r !== s))}><X className="text-muted-foreground" /></button>
                    </div>
                  ))}
                  {recent.length > 0 && <div className="mt-6 text-center"><button onClick={() => setRecent([])} className="rounded-full border px-5 py-2 text-sm font-bold">Clear recent searches</button></div>}
                </div>
              </div>
            )}
            {screen === "profile" && (
              <div className="bg-gradient-to-b from-surface-2 to-background px-4 pt-4">
                <button onClick={() => setScreen("home")}><ChevronLeft className="size-7" /></button>
                <div className="mt-4 flex items-center gap-4">
                  <div className="grid size-28 place-items-center rounded-full bg-avatar text-6xl text-primary-foreground">J</div>
                  <div><h1 className="text-2xl font-extrabold">juhpisciotta8</h1><p className="text-sm text-muted-foreground"><b className="text-foreground">0</b> followers • <b className="text-foreground">7</b> following</p></div>
                </div>
                <div className="mt-6 flex items-center gap-6"><button className="rounded-full border px-4 py-1.5 text-sm font-bold">Edit</button><Share className="text-muted-foreground" /><MoreHorizontal className="text-muted-foreground" /></div>
                <div className="mt-24 text-center"><h2 className="text-2xl font-extrabold">No recent activity.</h2><p className="mt-2 text-sm text-muted-foreground">Check out some new music now</p></div>
              </div>
            )}
            {screen === "library" && <div className="p-4"><h1 className="text-2xl font-extrabold">Your Library</h1><p className="mt-2 text-muted-foreground">Nothing here yet.</p></div>}
          </main>

          <div className="fixed inset-x-0 bottom-0 mx-auto max-w-md bg-gradient-to-t from-background via-background to-transparent px-2 pt-6">
            <div className="flex items-center gap-3 rounded-lg bg-player p-2">
              <Cover hue={track[2]} size="size-10" />
              <div className="flex-1 text-sm"><div>{track[0]}</div><div className="text-muted-foreground">{track[1]}</div></div>
              <MonitorSpeaker /><button onClick={() => setPlaying(!playing)} className="px-2">{playing ? <Pause fill="currentColor" /> : <Play fill="currentColor" />}</button>
            </div>
            <nav className="flex justify-around py-2 text-xs">
              {([["home", Home, "Home"], ["search", Search, "Search"], ["library", Library, "Your Library"], ["create", Plus, "Create"]] as const).map(([k, I, l]) => (
                <button key={k} onClick={() => k !== "create" && setScreen(k)} className={`flex flex-col items-center gap-1 ${screen === k ? "" : "text-muted-foreground"}`}><I className="size-6" strokeWidth={2.2} />{l}</button>
              ))}
            </nav>
          </div>

          {drawer && (
            <div className="fixed inset-0 z-50 flex" onClick={() => setDrawer(false)}>
              <div className="h-full w-[88%] max-w-sm bg-surface animate-in slide-in-from-left" onClick={(e) => e.stopPropagation()}>
                <button onClick={() => { setScreen("profile"); setDrawer(false); }} className="flex w-full items-center gap-3 border-b p-4 text-left">
                  <div className="grid size-12 place-items-center rounded-full bg-avatar text-2xl font-bold text-primary-foreground">J</div>
                  <div><div className="text-lg font-extrabold">juhpisciotta8</div><div className="text-sm text-muted-foreground">View profile</div></div>
                </button>
                <ul className="space-y-6 p-4">
                  <li className="flex gap-3"><PlusCircle />Add account</li>
                  <li className="flex items-center gap-3"><Logo className="size-6" />Your Premium</li>
                  <li className="flex gap-3"><Zap />What's new</li>
                  <li className="flex gap-3"><Clock />Recents</li>
                  <li className="flex gap-3"><Megaphone />Your Updates • <span className="text-link">New</span></li>
                  <li className="flex gap-3"><Settings />Settings and privacy</li>
                  <li><button onClick={() => { setScreen("signup"); setDrawer(false); }} className="text-muted-foreground">Log out</button></li>
                </ul>
                <div className="px-4"><h3 className="text-lg font-extrabold">Messages</h3><p className="text-sm text-muted-foreground">Share what you love with friends.</p>
                  <div className="mt-4 flex items-center gap-3"><div className="grid size-12 place-items-center rounded-full bg-surface-2"><SquarePen /></div>New message</div></div>
              </div>
              <div className="flex-1 bg-background/60" />
            </div>
          )}
        </>
      )}
    </div>
  );
}
