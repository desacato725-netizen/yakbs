# Sonora

Telas do app de música (cadastro, login, início, busca, perfil, biblioteca, menu lateral e player).

- src/routes/index.tsx: todas as telas
- src/routes/__root.tsx: raiz do app
- src/styles.css: cores e fonte
